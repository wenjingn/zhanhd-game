/*
 +----------------------------------------------------------------------+
 | Swoole                                                               |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | license@php.net so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 | Author: Tianfeng Han  <mikan.tenny@gmail.com>                        |
 +----------------------------------------------------------------------+
 */

#include "swoole.h"
#include "Server.h"

static int swReactorProcess_loop(swProcessPool *pool, swWorker *worker);
static int swReactorProcess_onPipeRead(swReactor *reactor, swEvent *event);
static void swReactorProcess_timer_init(swServer *serv, swReactor *reactor);
static void swReactorProcess_onTimer(swTimer *timer, swTimer_node *event);

int swReactorProcess_create(swServer *serv)
{
    serv->reactor_num = 1;
    serv->reactor_threads = sw_calloc(1, sizeof(swReactorThread));
    if (serv->reactor_threads == NULL)
    {
        swSysError("calloc[1](%d) failed.", (int )(serv->reactor_num * sizeof(swReactorThread)));
        return SW_ERR;
    }
    serv->connection_list = sw_calloc(serv->max_connection, sizeof(swConnection));
    if (serv->connection_list == NULL)
    {
        swSysError("calloc[2](%d) failed.", (int )(serv->max_connection * sizeof(swConnection)));
        return SW_ERR;
    }

#ifdef SW_REACTOR_USE_SESSION
    serv->session_list = sw_calloc(SW_SESSION_LIST_SIZE, sizeof(swSession));
    if (serv->session_list == NULL)
    {
        swSysError("calloc[2](%ld) failed.", SW_SESSION_LIST_SIZE * sizeof(swSession));
        return SW_ERR;
    }
#endif

    //create factry object
    if (swFactory_create(&(serv->factory)) < 0)
    {
        swError("create factory failed.");
        return SW_ERR;
    }
    return SW_OK;
}

/**
 * base模式
 * 在worker进程中直接accept连接
 */
int swReactorProcess_start(swServer *serv)
{
    if (serv->onStart != NULL)
    {
        serv->onStart(serv);
    }
    //listen UDP
    if (serv->have_udp_sock == 1)
    {
        swListenList_node *listen_host;
        LL_FOREACH(serv->listen_list, listen_host)
        {
            //UDP
            if (listen_host->type == SW_SOCK_UDP || listen_host->type == SW_SOCK_UDP6
                    || listen_host->type == SW_SOCK_UNIX_DGRAM)
            {
                serv->connection_list[listen_host->sock].info.addr.inet_v4.sin_port = htons(listen_host->port);
                serv->connection_list[listen_host->sock].fd = listen_host->sock;
                serv->connection_list[listen_host->sock].object = listen_host;
            }
        }
    }
    //listen TCP
    if (serv->have_tcp_sock == 1)
    {
        //listen server socket
        if (swServer_listen(serv, NULL) < 0)
        {
            return SW_ERR;
        }
    }

    int create_pipe = serv->onPipeMessage ? 1 : 0;

    if (swProcessPool_create(&SwooleGS->event_workers, serv->worker_num, serv->max_request, 0, create_pipe) < 0)
    {
        return SW_ERR;
    }

    SwooleGS->event_workers.ptr = serv;
    SwooleGS->event_workers.main_loop = swReactorProcess_loop;
    SwooleGS->event_workers.type = SW_PROCESS_WORKER;

    //no worker
    if (serv->worker_num == 1 && SwooleG.task_worker_num == 0 && serv->max_request == 0)
    {
        swWorker single_worker;
        single_worker.id = 0;
        return swReactorProcess_loop(&SwooleGS->event_workers, &single_worker);
    }

    //task workers
    if (SwooleG.task_worker_num > 0)
    {
        key_t key = 0;
        if (SwooleG.task_ipc_mode == SW_IPC_MSGQUEUE)
        {
            key = serv->message_queue_key;
        }

        if (swProcessPool_create(&SwooleGS->task_workers, SwooleG.task_worker_num, serv->task_max_request, key, 1) < 0)
        {
            swWarn("[Master] create task_workers failed.");
            return SW_ERR;
        }

        swTaskWorker_init(&SwooleGS->task_workers);
        swProcessPool_start(&SwooleGS->task_workers);

        int i;
        for (i = 0; i < SwooleGS->task_workers.worker_num; i++)
        {
            swProcessPool_add_worker(&SwooleGS->event_workers, &SwooleGS->task_workers.workers[i]);
        }
    }
    /**
     * BASE模式，管理进程就是主进程
     */
    SwooleG.pid = SwooleGS->manager_pid = getpid();
    SwooleG.process_type = SW_PROCESS_MASTER;

    SwooleG.use_timerfd = 0;
    SwooleG.use_signalfd = 0;
    SwooleG.use_timer_pipe = 0;
    swServer_signal_init();

    swProcessPool_start(&SwooleGS->event_workers);
    swProcessPool_wait(&SwooleGS->event_workers);

    swProcessPool_shutdown(&SwooleGS->event_workers);
    sw_free(serv->session_list);

    return SW_OK;
}

static int swReactorProcess_onPipeRead(swReactor *reactor, swEvent *event)
{
    swEventData task;
    swServer *serv = reactor->ptr;

    if (read(event->fd, &task, sizeof(task)) > 0)
    {
        serv->onPipeMessage(serv, &task);
        return SW_OK;
    }
    return SW_ERR;
}

static int swReactorProcess_loop(swProcessPool *pool, swWorker *worker)
{
    swServer *serv = pool->ptr;
    swReactor *reactor = &(serv->reactor_threads[0].reactor);

    SwooleG.process_type = SW_PROCESS_WORKER;
    SwooleG.pid = getpid();

    SwooleWG.id = worker->id;
    SwooleWG.request_num = serv->max_request;

    swServer_worker_init(serv, worker);

    //create reactor
    if (swReactor_create(reactor, SW_REACTOR_MAXEVENTS) < 0)
    {
        swWarn("ReactorProcess create failed.");
        return SW_ERR;
    }

    swListenList_node *ls;
    int fdtype;

    //listen the all tcp port
    LL_FOREACH(serv->listen_list, ls)
    {
        fdtype = (ls->type == SW_SOCK_UDP || ls->type == SW_SOCK_UDP6 || ls->type == SW_SOCK_UNIX_DGRAM) ?
                        SW_FD_UDP : SW_FD_LISTEN;
        serv->connection_list[ls->sock].fd = ls->sock;
        serv->connection_list[ls->sock].socket_type = ls->type;
        reactor->add(reactor, ls->sock, fdtype);
    }
    SwooleG.main_reactor = reactor;

    reactor->id = 0;
    reactor->ptr = serv;

#ifdef SW_USE_RINGBUFFER
    serv->reactor_threads[0].buffer_input = swMalloc_new();
    if (serv->reactor_threads[0].buffer_input == NULL)
    {
        return SW_ERR;
    }
#endif

#ifdef HAVE_SIGNALFD
    if (SwooleG.use_signalfd)
    {
        swSignalfd_setup(SwooleG.main_reactor);
    }
#endif

    reactor->thread = 1;
    reactor->socket_list = serv->connection_list;
    reactor->max_socket = serv->max_connection;
    
    reactor->disable_accept = 0;
    reactor->enable_accept = swServer_enable_accept;

    reactor->close = swReactorThread_close;

    //set event handler
    //connect
    reactor->setHandle(reactor, SW_FD_LISTEN, swServer_master_onAccept);
    //close
    reactor->setHandle(reactor, SW_FD_CLOSE, swReactorProcess_onClose);
    //pipe
    reactor->setHandle(reactor, SW_FD_PIPE | SW_EVENT_WRITE, swReactor_onWrite);

    if (serv->onPipeMessage)
    {
        reactor->add(reactor, worker->pipe_worker, SW_FD_PIPE);
        //close
        reactor->setHandle(reactor, SW_FD_PIPE, swReactorProcess_onPipeRead);
    }

    //set protocol function point
    swReactorThread_set_protocol(serv, reactor);

    if (serv->onWorkerStart)
    {
        serv->onWorkerStart(serv, worker->id);
    }

    /**
     * for heartbeat check
     */
    if (serv->heartbeat_check_interval > 0)
    {
        swReactorProcess_timer_init(serv, reactor);
    }

    struct timeval timeo;
    timeo.tv_sec = SW_MAINREACTOR_TIMEO;
    timeo.tv_usec = 0;
    reactor->wait(reactor, &timeo);

    return SW_OK;
}

int swReactorProcess_onClose(swReactor *reactor, swEvent *event)
{
    swServer *serv = reactor->ptr;
    if (serv->onClose != NULL)
    {
        serv->onClose(serv, event->fd, event->from_id);
    }
    return reactor->close(reactor, event->fd);
}

static void swReactorProcess_timer_init(swServer *serv, swReactor *reactor)
{
    SwooleG.timer.onTimer = swReactorProcess_onTimer;
    int interval_ms = serv->heartbeat_check_interval * 1000;
    swEventTimer_init();
    reactor->timeout_msec = interval_ms;
    SwooleG.timer.interval = interval_ms;
    SwooleG.timer.add(&SwooleG.timer, interval_ms, 1, serv);
}

static void swReactorProcess_onTimer(swTimer *timer, swTimer_node *event)
{
    swServer *serv = SwooleG.serv;

    if (event->data == serv)
    {
        swFactory *factory = &serv->factory;
        swConnection *conn;

        int fd;
        int serv_max_fd;
        int serv_min_fd;
        int checktime;

        serv_max_fd = swServer_get_maxfd(serv);
        serv_min_fd = swServer_get_minfd(serv);

        checktime = (int) time(NULL) - serv->heartbeat_idle_time;

        for (fd = serv_min_fd; fd <= serv_max_fd; fd++)
        {
            conn = swServer_connection_get(serv, fd);
            if (conn != NULL && 1 == conn->active && conn->last_time < checktime)
            {
                factory->end(&serv->factory, fd);
            }
        }
    }
    else
    {
        swServer_onTimer(timer, event);
    }
}
