/**
 * $Id
 */

#include "npbd.h"
#include "autoloader.h"

static void php_npbd_autoloader_free_storage(php_npbd_autoloader *object TSRMLS_DC)
{
    if (object->prefix) {
        efree(object->prefix);
    }

    if (object->target) {
        efree(object->target);
    }

    zend_object_std_dtor(&object->zo TSRMLS_CC);
    efree(object);
}

static zend_object_value php_npbd_autoloader_create_object(zend_class_entry *ce TSRMLS_DC)
{
    zend_object_value retval;
    php_npbd_std_new_object(php_npbd_autoloader);

    return retval;
}

/* {{{ proto public PsrAutoloader PsrAutoloader::__construct(); */
PHP_METHOD(autoloader, __construct)
{
    zend_error_handling zeh;
    zval *autoload,
         *loadclass,
         *retval = NULL,
         *instance = getThis();

    zend_replace_error_handling(EH_THROW, NULL, &zeh TSRMLS_CC);
    if (zend_parse_parameters_none() == FAILURE) {
        zend_restore_error_handling(&zeh TSRMLS_CC);
        return;
    }
    zend_restore_error_handling(&zeh TSRMLS_CC);

    MAKE_STD_ZVAL(autoload);
    array_init(autoload);

    MAKE_STD_ZVAL(loadclass);
    ZVAL_STRING(loadclass, "loadclass", 1);

    Z_ADDREF_P(instance);
    zend_hash_next_index_insert(Z_ARRVAL_P(autoload), (void **) &instance,  sizeof(zval *), NULL);
    zend_hash_next_index_insert(Z_ARRVAL_P(autoload), (void **) &loadclass, sizeof(zval *), NULL);

    zend_call_method(NULL, NULL, NULL, ZEND_STRL("spl_autoload_register"), &retval, 1, autoload, NULL TSRMLS_CC);
    if (retval) {
        zval_ptr_dtor(&retval);
    }

    zval_ptr_dtor(&autoload);
}
/* }}} */

/* {{{ proto public void PsrAutoloader::register(string prefix, string target); */
PHP_METHOD(autoloader, register)
{
    char *prefix,
         *target;
    uint  prefix_len,
          target_len;

    if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "ss", &prefix, &prefix_len, &target, &target_len) == FAILURE) {
        return;
    }

    php_npbd_autoloader *object = php_npbd_std_get_object(php_npbd_autoloader, getThis());
    if (object->prefix) {
        efree(object->prefix);
    }

    if (object->target) {
        efree(object->target);
    }

    object->prefix = estrndup(prefix, prefix_len);
    object->target = estrndup(target, target_len);

    object->prefix_len = prefix_len;
    object->target_len = target_len;
}
/* }}} */

/* {{{ proto public mixed PsrAutoloader::loadclass(string classname); */
PHP_METHOD(autoloader, loadclass)
{
    zend_file_handle fh;
    const char *p,
               *q;
    char *classname,
         *s,
         *t,
          realpath[MAXPATHLEN];
    uint  classname_len,
          n;

    if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &classname, &classname_len) == FAILURE) {
        return;
    }

    php_npbd_autoloader *object = php_npbd_std_get_object(php_npbd_autoloader, getThis());
    if (object->prefix == NULL || object->target == NULL) {
        RETURN_FALSE;
    }

    p = classname;
    n = classname_len;
    while (NULL != (q = memrchr(p, '\\', n))) {
        if (strncmp(p, object->prefix, q - p)) {
            n = q - p;
        } else {
            n = spprintf(&t, 0, "%s%s.php", object->target, p + object->prefix_len);
            s = t;
            while (s = strchr(s, '\\')) {
                *s = '/';
                ++s;
            }

            if (NULL == VCWD_REALPATH(t, realpath)) {
                efree(t);
                RETURN_FALSE;
            }

            fh.type             = ZEND_HANDLE_FILENAME;
            fh.filename         = t;
            fh.opened_path      = NULL;
            fh.free_filename    = 0;
            zend_execute_scripts(ZEND_INCLUDE TSRMLS_CC, NULL, 1, &fh);

            RETVAL_STRINGL(t, n, 1);
            efree(t);
            return;
        }
    }

    RETURN_FALSE;
}
/* }}} */

ZEND_BEGIN_ARG_INFO_EX(ArgInfo_npbd_autoloader_void, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(ArgInfo_npbd_autoloader_register, 0, 0, 2)
    ZEND_ARG_TYPE_INFO(0, prefix, 0, 0)
    ZEND_ARG_TYPE_INFO(0, target, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(ArgInfo_npbd_autoloader_loadclass, 0, 0, 1)
    ZEND_ARG_TYPE_INFO(0, classname, 0, 0)
ZEND_END_ARG_INFO()

static const zend_function_entry php_npbd_autoloader_methods[] = {
    PHP_ME(autoloader, __construct, ArgInfo_npbd_autoloader_void,       ZEND_ACC_PUBLIC | ZEND_ACC_CTOR)
    PHP_ME(autoloader, register,    ArgInfo_npbd_autoloader_register,   ZEND_ACC_PUBLIC)
    PHP_ME(autoloader, loadclass,   ArgInfo_npbd_autoloader_loadclass,  ZEND_ACC_PUBLIC)
    PHP_FE_END
};

void php_npbd_autoloader_class(TSRMLS_D)
{
    zend_class_entry ce;

    INIT_CLASS_ENTRY(ce, "PsrAutoloader", php_npbd_autoloader_methods);
    php_npbd_ce_autoloader = zend_register_internal_class(&ce TSRMLS_CC);
    php_npbd_ce_autoloader->create_object = php_npbd_autoloader_create_object;
    php_npbd_ce_autoloader->ce_flags |= ZEND_ACC_FINAL_CLASS;
}
