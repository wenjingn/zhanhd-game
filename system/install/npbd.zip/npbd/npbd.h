/**
 * $Id
 */

#ifndef PHP_NPBD_NPBD_H
#define PHP_NPBD_NPBD_H

#include "php_npbd.h"

typedef struct {
    zend_object zo;
    char *prefix;
    char *target;
    uint  prefix_len;
    uint  target_len;
} php_npbd_autoloader;

#define php_npbd_std_new_object(struct_name)                                \
    struct_name *object = (struct_name *) emalloc(sizeof(struct_name));     \
    memset(object, 0, sizeof(struct_name));                                 \
                                                                            \
    zend_object_std_init(&object->zo, ce TSRMLS_CC);                        \
    object_properties_init(&object->zo, ce);                                \
                                                                            \
    retval.handle = zend_objects_store_put(object,                          \
        (zend_objects_store_dtor_t) zend_objects_destroy_object,            \
        (zend_objects_free_object_storage_t) struct_name##_free_storage,    \
        NULL TSRMLS_CC);                                                    \
    retval.handlers = zend_get_std_object_handlers();

#define php_npbd_std_get_object(struct_name, instance)                      \
    (struct_name *) zend_object_store_get_object(instance TSRMLS_CC);

#endif
