/**
 * $Id
 */

#ifndef PHP_NPBD_H
#define PHP_NPBD_H

#define PHP_NPBD_EXTNAME "npbd"
#define PHP_NPBD_VERSION "0.9.24"

#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include "php.h"
#include "zend_exceptions.h"

#ifdef ZTS
# include "TSRM.h"
#endif

extern zend_module_entry npbd_module_entry;
#define phpext_npbd_ptr &npbd_module_entry

extern zend_class_entry *php_npbd_ce_exception;
extern zend_class_entry *php_npbd_ce_autoloader;

ZEND_BEGIN_MODULE_GLOBALS(npbd)
ZEND_END_MODULE_GLOBALS(npbd)

ZEND_EXTERN_MODULE_GLOBALS(npbd)

#ifdef ZTS
# define NPBDG(v) TSRMG(npbd_globals_id, zend_npbd_globals *, v)
#else
# define NPBDG(v) (npbd_globals.v)
#endif

#endif
