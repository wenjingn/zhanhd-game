/**
 * $Id
 */

#ifndef PHP_NPBD_AUTOLOADER_H
#define PHP_NPBD_AUTOLOADER_H

#include "php_npbd.h"

void php_npbd_autoloader_class(TSRMLS_D);

#endif
