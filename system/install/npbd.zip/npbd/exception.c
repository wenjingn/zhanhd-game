/**
 * $Id
 */

#include "npbd.h"
#include "exception.h"

zend_class_entry *spl_ce_RuntimeException = NULL;

static zend_class_entry *npbd_get_exception_base(TSRMLS_D)
{
    if (spl_ce_RuntimeException == NULL) {
        zend_class_entry **pce;
        if (zend_hash_find(CG(class_table), "runtimeexception", sizeof("RuntimeException"), (void **) &pce) == SUCCESS) {
            spl_ce_RuntimeException = *pce;
            return *pce;
        }
    }

    return zend_exception_get_default(TSRMLS_C);
}

/* {{{ proto public VariadicException VariadicException::__construct([string message [, int code [, Exception previous [, mixed arg1 [, mixed arg2 , ...]]]]]); */
PHP_METHOD(exception, __construct)
{
    zval ***params = NULL,
           *dummy,
           *param,
           *previous = NULL,
           *instance = getThis();

    char *message = NULL;
    long  code = 0;
    int   i,
          message_len,
          params_num = 0;

    if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "|slO!!+", &message, &message_len, &code, &previous, npbd_get_exception_base(TSRMLS_C), &params, &params_num) == FAILURE) {
        zend_error(E_ERROR, "Invalid parameters for VariadicException");
    }

    if (message) {
        zend_update_property_string(Z_OBJCE_P(instance), instance, ZEND_STRL("message"), message TSRMLS_CC);
    }

    if (code) {
        zend_update_property_long(Z_OBJCE_P(instance), instance, ZEND_STRL("code"), code TSRMLS_CC);
    }

    if (previous) {
        zend_update_property(Z_OBJCE_P(instance), instance, ZEND_STRL("previous"), previous TSRMLS_CC);
    }

    MAKE_STD_ZVAL(dummy);
    array_init_size(dummy, 0);

    if (params_num > 0) {
        for (i = 0; i < params_num; i++) {
            SEPARATE_ZVAL_IF_NOT_REF(params[i]);
            Z_ADDREF_P(*params[i]);
            add_next_index_zval(dummy, *params[i]);
        }

        efree(params);
    }

    zend_update_property(Z_OBJCE_P(instance), instance, ZEND_STRL("params"), dummy TSRMLS_CC);
    zval_ptr_dtor(&dummy);
}
/* }}} */

/* {{{ proto public array VariadicException::getParams(void); */
PHP_METHOD(exception, getParams)
{
    if (zend_parse_parameters_none() == FAILURE) {
        return;
    }

    zval *object = getThis();
    zval *params = zend_read_property(Z_OBJCE_P(object), object, ZEND_STRL("params"), 1 TSRMLS_CC);
    RETURN_ZVAL(params, 1, 0);
}
/* }}} */

ZEND_BEGIN_ARG_INFO_EX(ArgInfo_npbd_exception_void, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(ArgInfo_npbd_exception_ctor, 0, 0, 0)
    ZEND_ARG_TYPE_INFO(0, message, 0, 0)
    ZEND_ARG_TYPE_INFO(0, code, 0, 0)
    ZEND_ARG_TYPE_INFO(0, previous, 0, 0)
    ZEND_ARG_VARIADIC_INFO(0, params)
ZEND_END_ARG_INFO()

static const zend_function_entry php_npbd_exception_methods[] = {
    PHP_ME(exception, __construct,  ArgInfo_npbd_exception_ctor,    ZEND_ACC_PUBLIC)
    PHP_ME(exception, getParams,    ArgInfo_npbd_exception_void,    ZEND_ACC_PUBLIC)
    PHP_FE_END
};

void php_npbd_exception_class(TSRMLS_D)
{
    zend_class_entry ce;

    INIT_CLASS_ENTRY(ce, "VariadicException", php_npbd_exception_methods);
    php_npbd_ce_exception = zend_register_internal_class_ex(&ce, npbd_get_exception_base(TSRMLS_C), NULL TSRMLS_CC);

    zend_declare_property_null(php_npbd_ce_exception, ZEND_STRL("params"), ZEND_ACC_PRIVATE TSRMLS_CC);
}
