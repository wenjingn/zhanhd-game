/**
 * $Id
 */

#ifndef PHP_NPBD_EXCEPTION_H
#define PHP_NPBD_EXCEPTION_H

#include "php_npbd.h"

void php_npbd_exception_class(TSRMLS_D);

#endif
