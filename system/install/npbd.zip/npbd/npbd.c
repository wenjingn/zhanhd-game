/**
 * $Id
 */

#include "npbd.h"

#include "exception.h"
#include "autoloader.h"

zend_class_entry *php_npbd_ce_exception;
zend_class_entry *php_npbd_ce_autoloader;

ZEND_DECLARE_MODULE_GLOBALS(npbd)

static PHP_GINIT_FUNCTION(npbd)
{
}

static PHP_MINIT_FUNCTION(npbd)
{
    php_npbd_exception_class(TSRMLS_C);
    php_npbd_autoloader_class(TSRMLS_C);
    return SUCCESS;
}

static PHP_RINIT_FUNCTION(npbd)
{
    return SUCCESS;
}

static PHP_RSHUTDOWN_FUNCTION(npbd)
{
    return SUCCESS;
}

static PHP_MINFO_FUNCTION(npbd)
{
    php_info_print_table_start();

    php_info_print_table_row(2, "npbd support", "enabled");
    php_info_print_table_row(2, "npbd version", PHP_NPBD_VERSION);

    php_info_print_table_end();
}

static int format_long_options(void *pDest TSRMLS_DC, int num_args, va_list args, zend_hash_key *hash_key)
{
    HashTable *long_opts = va_arg(args, HashTable *);
    zval *option;

    if (hash_key->nKeyLength == 0) {
        return ZEND_HASH_APPLY_KEEP;
    }

    MAKE_STD_ZVAL(option);
    Z_TYPE_P(option)   = IS_STRING;
    Z_STRLEN_P(option) = spprintf(&Z_STRVAL_P(option), 0, "%s::", hash_key->arKey);

    zend_hash_next_index_insert(long_opts, (void **) &option, sizeof(zval *), NULL);
    return ZEND_HASH_APPLY_KEEP;
}

static int finalize_parsed_options(void *pDest TSRMLS_DC, int num_args, va_list args, zend_hash_key *hash_key)
{
    HashTable *parsed_opts = va_arg(args, HashTable *);
    zval **optval = (zval **) pDest;

    if (Z_TYPE_PP(optval) == IS_NULL || zend_hash_quick_exists(parsed_opts, hash_key->arKey, hash_key->nKeyLength, hash_key->h) == 1) {
        return ZEND_HASH_APPLY_KEEP;
    }

    if (Z_TYPE_PP(optval) == IS_BOOL && Z_BVAL_PP(optval) == 0) {
        zend_throw_exception_ex(NULL, 0 TSRMLS_CC, "required option --%s was not provided", hash_key->arKey);
        return ZEND_HASH_APPLY_STOP;
    }

    Z_ADDREF_PP(optval);
    zend_hash_quick_update(parsed_opts, hash_key->arKey, hash_key->nKeyLength, hash_key->h, (void **) optval, sizeof(zval *), NULL);

    return ZEND_HASH_APPLY_KEEP;
}

/* {{{ proto string usdate(void); */
PHP_FUNCTION(usdate)
{
    struct timeval tv;
    char buffer[32];
    int  length;

    if (zend_parse_parameters_none() == FAILURE) {
        return;
    }

    if (gettimeofday(&tv, NULL)) {
        return;
    }

    length = strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", localtime(&tv.tv_sec));
    length = snprintf(buffer + length, sizeof(buffer) - length, ".%03d", (int) tv.tv_usec/1000);

    RETURN_STRINGL(buffer, strlen(buffer), 1);
}
/* }}} */

/* {{{ proto int ustime([boolean getAsStdObject = false]); */
PHP_FUNCTION(ustime)
{
    zend_bool getAsStdObject = 0;
    struct timeval tv;

    if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "|b", &getAsStdObject) == FAILURE) {
        return;
    }

    if (gettimeofday(&tv, NULL)) {
        return;
    }

    if (getAsStdObject) {
        object_init(return_value);
        zend_update_property_long(Z_OBJCE_P(return_value), return_value, ZEND_STRL("sec"),  tv.tv_sec  TSRMLS_CC);
        zend_update_property_long(Z_OBJCE_P(return_value), return_value, ZEND_STRL("usec"), tv.tv_usec TSRMLS_CC);
    } else {
        RETURN_LONG(tv.tv_sec * 1000000 + tv.tv_usec);
    }
}
/* }}} */

/* {{{ proto array getlongopt(array options); */
PHP_FUNCTION(getlongopt)
{
    zval **initial,
          *options,
          *long_opts,
          *short_opts,
          *parsed_opts = NULL;

    if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "a", &options) == FAILURE || zend_hash_num_elements(Z_ARRVAL_P(options)) == 0 || return_value_used == 0) {
        return;
    }

    MAKE_STD_ZVAL(long_opts);
    array_init_size(long_opts, zend_hash_num_elements(Z_ARRVAL_P(options)));
    zend_hash_apply_with_arguments(Z_ARRVAL_P(options) TSRMLS_CC, (apply_func_args_t) format_long_options, 1, Z_ARRVAL_P(long_opts));

    MAKE_STD_ZVAL(short_opts);
    ZVAL_NULL(short_opts);

    zend_call_method(NULL, NULL, NULL, ZEND_STRL("getopt"), &parsed_opts, 2, short_opts, long_opts TSRMLS_CC);
    zval_ptr_dtor(&long_opts);
    zval_ptr_dtor(&short_opts);

    if (parsed_opts && Z_TYPE_P(parsed_opts) == IS_ARRAY) {
        zend_hash_apply_with_arguments(Z_ARRVAL_P(options) TSRMLS_CC, (apply_func_args_t) finalize_parsed_options, 1, Z_ARRVAL_P(parsed_opts));
        if (EG(exception)) {
            return;
        }

        RETURN_ZVAL(parsed_opts, 1, 1);
    }
}
/* }}} */

ZEND_BEGIN_ARG_INFO_EX(ArgInfo_npbd_func_usdate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(ArgInfo_npbd_func_ustime, 0, 0, 0)
    ZEND_ARG_TYPE_INFO(0, getAsStdObject, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(ArgInfo_npbd_func_getlongopt, 0, 0, 1)
    ZEND_ARG_TYPE_INFO(0, options, IS_ARRAY, 0)
ZEND_END_ARG_INFO()

static const zend_function_entry php_npbd_functions[] = {
    PHP_FE(usdate,      ArgInfo_npbd_func_usdate)
    PHP_FE(ustime,      ArgInfo_npbd_func_ustime)
    PHP_FE(getlongopt,  ArgInfo_npbd_func_getlongopt)
    PHP_FE_END
};

zend_module_entry npbd_module_entry = {
    STANDARD_MODULE_HEADER,
    PHP_NPBD_EXTNAME,
    php_npbd_functions,
    PHP_MINIT(npbd),
    NULL,
    PHP_RINIT(npbd),
    PHP_RSHUTDOWN(npbd),
    PHP_MINFO(npbd),
    PHP_NPBD_VERSION,
    PHP_MODULE_GLOBALS(npbd),
    PHP_GINIT(npbd),
    NULL,
    NULL,
    STANDARD_MODULE_PROPERTIES_EX
};

#ifdef COMPILE_DL_NPBD
ZEND_GET_MODULE(npbd)
#endif
